{
    'name': 'Sample Marketplace Addon',
    'version': '17.0.1.0.0',
    'summary': 'Fixture module for marketplace install tests',
    'depends': ['base'],
    'author': 'Odoo Vite Tests',
    'license': 'LGPL-3',
}
